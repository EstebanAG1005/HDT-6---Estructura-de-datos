# HojaDeTrabajo6
Repositorio de la HT6 - Estructura de datos
